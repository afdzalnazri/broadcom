#!/bin/bash
# 2 should be the file name diag.txt
# 3 should be 1.... i think its the number of loop, comes from stress test, with
#FCTPRG it only passes in file name
card_num=$1
num_loops=$2
output_file=$3

#obtains directory of this script (useful when caller is in another directory
# so relative paths work correctly)
DIR="${BASH_SOURCE%/*}"
if [[ ! -d "$DIR" ]]; then DIR="$PWD"; fi
cd $DIR

#deletes file if it exists
if [ -s $output_file ]; then
    rm $output_file
fi

echo "-------------------------------------------------------------------------"
echo "this is unable to handle more than one card at a time. Specify a "
echo "device/function actually prevents the card from programming correctly."
echo "there is currently no fix for this, perhaps we will only have one slot"
echo "on at a time in the final version"
echo "-------------------------------------------------------------------------"
#CFGCHK.TXT.IN was originally named CFGCHK.TXT The .in was added to indicate the
# file is for input rather than output
#echo ./mfgload.sh -dev $(($card_num + 1)) -sysop -no_swap -cof -cfgchk CFGCHK.TXT.IN -I $num_loops -log $output_file
echo ./mfgload.sh -sysop -no_swap -T A1D3E1 -cfgchk CFGCHK.TXT.IN -I $num_loops -log $output_file
./mfgload.sh -dev -sysop -no_swap -T A1D3E1 -cfgchk CFGCHK.TXT.IN -I $num_loops -log $output_file

echo "FCT test completed" >> $output_file

#43+
